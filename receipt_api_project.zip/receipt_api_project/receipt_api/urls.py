
from django.urls import path
from . import views

urlpatterns = [
    path('upload-form/', views.upload_form, name='upload_form'),
    path('process-xml/', views.process_xml, name='process_xml'),
    # other URL patterns as needed
]

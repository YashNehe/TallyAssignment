from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import pandas as pd
import xml.etree.ElementTree as ET
from datetime import datetime


from django.shortcuts import render

def upload_form(request):
        return render(request, 'upload_form.html')

    # Function to parse XML and generate DataFrame
def parse_tally_xml(xml_file_path):
        
    @csrf_exempt
    def process_xml(request):
        if request.method == 'POST' and request.FILES.get('xml_file'):
            xml_file = request.FILES['xml_file']
            
            
            with open('Input.xml', 'wb') as destination:
                for chunk in xml_file.chunks():
                    destination.write(chunk)

            # Parse the XML file
            vouchers = parse_tally_xml('Input.xml')

            # Create a DataFrame from vouchers list
            df = pd.DataFrame(vouchers)

            # Save DataFrame to Excel
            excel_filename = 'tally_receipt_daybook.xlsx'
            df.to_excel(excel_filename, index=False)

            # Respond with success message
            response = {
                'message': f'Excel file "{excel_filename}" has been created successfully.'
            }
            return JsonResponse(response)

        # Handle invalid requests (GET requests or missing file)
        return JsonResponse({'error': 'Invalid request or missing XML file.'}, status=400)
